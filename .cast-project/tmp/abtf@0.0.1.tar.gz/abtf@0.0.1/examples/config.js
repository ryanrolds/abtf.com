
module.exports = {
  'port': 3000,
  'session_secret': 'blahblahasdfasdf'
};