
module.exports = {
  'port': 3001,
  'session_secret': 'blahblahasdfasdf'
};