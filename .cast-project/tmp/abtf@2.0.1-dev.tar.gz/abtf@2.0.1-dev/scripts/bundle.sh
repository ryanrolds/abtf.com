#!/bin/bash

rm config.js
rm logs -R

cast bundles create