
var factorium = require('../lib/models/factorium');

describe('Factorium', function(){
  describe('#getRandomFactId()', function(){
    it('should return a fact', function(done){
      factorium.getRandomFactId(function(error, fact) {
        if(error) {
          throw error;
        }

        done();
      });
    })
  })
})