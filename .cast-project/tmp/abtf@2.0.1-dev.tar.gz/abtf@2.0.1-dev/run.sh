#!/bin/bash

/home/cast/local/node/bin/node server.js